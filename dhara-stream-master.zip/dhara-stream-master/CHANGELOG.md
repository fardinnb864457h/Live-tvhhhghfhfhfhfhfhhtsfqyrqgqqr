# Changelog

## v1.1.0 - April 16, 2025
### What's New
- Enhanced UI with smooth animations and transitions
- Multiple Playlist Support
### Bug Fixes
- Stream Quality Picker
### Installation Instructions
1. Download the installer for your operating system
2. Run the setup file
3. Follow installation prompts
4. Enjoy Dhara streaming app!
