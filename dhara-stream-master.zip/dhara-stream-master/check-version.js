console.log('Package.json version:', require('./package.json').version); console.log('Process env version:', process.env.npm_package_version);
